import livro from '../../imagens/livro.png'

export const livros = [
    {nome: 'Livro 1', id: 1, src: livro},
    {nome: 'Livro 2', id: 2, src: livro},
    {nome: 'Livro 3', id: 3, src: livro},
    {nome: 'Livro 4', id: 4, src: livro}
]